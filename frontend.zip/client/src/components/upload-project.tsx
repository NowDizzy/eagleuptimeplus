import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertProjectSchema } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { Loader2 } from "lucide-react";

export default function UploadProject() {
  const { toast } = useToast();
  const [file, setFile] = useState<File | null>(null);

  const form = useForm({
    resolver: zodResolver(insertProjectSchema),
    defaultValues: {
      name: "",
      botToken: "",
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const res = await fetch("/api/projects", {
        method: "POST",
        body: data,
        credentials: "include",
      });

      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || "Yükleme hatası oluştu");
      }

      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      form.reset();
      setFile(null);
      toast({
        title: "Başarılı",
        description: "Proje başarıyla yüklendi",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  async function onSubmit(values: { name: string; botToken: string }) {
    if (!file) {
      toast({
        title: "Hata",
        description: "Lütfen bir zip dosyası seçin",
        variant: "destructive",
      });
      return;
    }

    if (!file.name.endsWith('.zip')) {
      toast({
        title: "Hata",
        description: "Sadece .zip dosyaları yüklenebilir",
        variant: "destructive",
      });
      return;
    }

    if (!values.botToken) {
      toast({
        title: "Hata",
        description: "Bot token gereklidir",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData();
    formData.append("name", values.name);
    formData.append("botToken", values.botToken);
    formData.append("project", file);
    uploadMutation.mutate(formData);
  }

  return (
    <div className="max-w-md mx-auto">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Proje Adı</FormLabel>
                <FormControl>
                  <Input placeholder="Projenizin adını girin" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="botToken"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Bot Token</FormLabel>
                <FormControl>
                  <Input placeholder="Discord bot token'ınızı girin" {...field} type="password" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormItem>
            <FormLabel>Proje Dosyası (.zip)</FormLabel>
            <FormControl>
              <Input
                type="file"
                accept=".zip"
                onChange={(e) => setFile(e.target.files?.[0] || null)}
              />
            </FormControl>
            <FormMessage />
          </FormItem>

          <Button 
            type="submit" 
            disabled={uploadMutation.isPending}
            className="w-full"
          >
            {uploadMutation.isPending && (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            )}
            Projeyi Yükle
          </Button>
        </form>
      </Form>
    </div>
  );
}